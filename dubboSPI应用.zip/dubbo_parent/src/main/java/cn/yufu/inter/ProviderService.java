package cn.yufu.inter;

public interface ProviderService {

    String SayHello(String word);
}
