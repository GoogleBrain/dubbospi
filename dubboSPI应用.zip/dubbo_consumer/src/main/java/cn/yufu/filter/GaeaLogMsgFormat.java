package cn.yufu.filter;

public abstract class GaeaLogMsgFormat {

	protected static final String INFO_DIV = "-/-";
	
	protected static final String KV_DIV = "-:-";
	
	protected static final String LOG_ARGUMENT = "{}";
}
