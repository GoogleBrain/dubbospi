package cn.yufu.filter;

import com.alibaba.dubbo.rpc.*;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcException;

public class ConsumerTraceFilter extends DubboInteractionUtil implements Filter {
    private static final Logger logger = LoggerFactory.getLogger(ConsumerTraceFilter.class);

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        String interactionUUID = UUID.randomUUID().toString().replaceAll("-", "");
        logger.info("消费端>>>>>>"+interactionUUID);
        String methodName = invocation.getMethodName();

        InvocationAnnotations invocationAnnotations = getAnnotations(invoker.getInterface(), methodName, invocation.getParameterTypes());
        Object[] preDealtArguments = preDealForLogging(invocation.getArguments(), invocationAnnotations.getArgumentAnnotations());
        try {
            if(!FILTER_LOG.contains(methodName.toLowerCase())){
                logger.info(
                        FunIMsgFormat.MsgStyle.DEFAULT_LOG
                                .getFormat("invoke rpc-service[{}] invocation[{}] with params[{}]"),
                        new Object[] { methodName, interactionUUID,
                                //	GsonUtil.objToJson(invocation.getArguments())});
                                GsonUtil.objToJson(preDealtArguments) });
            }
            invocation.getAttachments().put(INTERACTION_UUID, interactionUUID);

            Result result = invoker.invoke(invocation);
            Object resultObj = result.getValue();

            Object preDealtResultObj = preDealForLogging(resultObj, invocationAnnotations.getResultAnnotations());
            if(!FILTER_LOG.contains(methodName.toLowerCase())){
                logger.info(
                        FunIMsgFormat.MsgStyle.DEFAULT_LOG.getFormat("rpc-service[{}] invocation[{}] return result[{}]"),
                        new Object[] { methodName, interactionUUID,
                                //GsonUtil.objToJson(resultObj) });
                                GsonUtil.objToJson(preDealtResultObj) });
            }
            return result;
        } catch (RpcException e) {
            logger.error(FunIMsgFormat.MsgStyle.DEFAULT_LOG.getFormat("rpc-service[{}] invocation[{}] is abort"),
                    methodName, interactionUUID);
            logger.error(FunIMsgFormat.HEAD, e);
            throw e;
        }
    }
}
