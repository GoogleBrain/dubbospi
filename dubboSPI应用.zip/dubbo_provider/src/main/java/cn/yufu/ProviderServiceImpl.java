package cn.yufu;

import cn.yufu.inter.ProviderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

public class ProviderServiceImpl implements ProviderService {
    private final Logger log = LoggerFactory.getLogger(ProviderServiceImpl.class);
    @Override
    public String SayHello(String word) {
        log.info("请求参数1：" + word);
        log.info("请求参数2：" + word);
        log.info("请求参数3：" + word);
        log.info("请求参数4：" + word);
        log.info("请求参数5：" + word);
        log.info("请求参数6：" + word);
        log.info("请求参数7：" + word);

        return "当前时间>>>>>>"+new Date()+","+word;
    }
}
